package com.example.login;

import java.io.IOException;
import java.net.URI;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.ParcelFormatException;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends ActionBarActivity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment implements LocationListener, OnClickListener, OnMapClickListener, OnInfoWindowClickListener{protected static final LatLng Hualien = null;
	//, OnClickListener
		
		LocationManager lm; 
		String best;
		MapView m;
		GoogleMap map;
		MarkerOptions markerOpt;
		HttpClient client; 
		//Button testButn;
	
		public PlaceholderFragment() {
		}
		
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			
						
			lm = (LocationManager) getActivity().getSystemService (Context.LOCATION_SERVICE);
			getActivity().getSystemService(Context.LOCATION_SERVICE);
			
			Criteria crit = new Criteria();
			crit.setAccuracy(Criteria.ACCURACY_FINE);
			best = lm.getBestProvider(crit, true);
			lm.requestLocationUpdates(best, 100, 0, this);
			
			
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			Button testButn = (Button) rootView.findViewById(R.id.button1);
			testButn.setOnClickListener(this);
			
			m = (MapView) rootView.findViewById(R.id.mapview);
			m.onCreate(savedInstanceState);
			this.setUpMapIfNeeded();
			
			
			map.setOnMapClickListener(this);
			map.setOnInfoWindowClickListener(this);
			//client = new DefaultHttpClient();
			client = (HttpClient) new DefaultHttpClient();
			return rootView;
		}
		public void onInfoWindowClick(Marker marker) {
	        marker.remove();
			
		}
		public void onMapClick(LatLng point) {
		        MarkerOptions markerOptions = new MarkerOptions();
		        markerOptions.position(point);
		        markerOptions.snippet("Tap here to remove this marker");
		        markerOptions.title("Marker Demo");

		        map.addMarker(markerOptions);
		}
		
		public void setUpMapIfNeeded() {
	        if (map == null) {
	            map =  m.getMap();
	            // Check if we were successful in obtaining the map.
	            if (map != null) {
	                 configureMap();
	            }
	        }
		}
		
		public void configureMap() {
			if (map == null)
		        return; // Google Maps not available
		    try {
		        MapsInitializer.initialize(getActivity());
		    }
		    catch (Exception e) {
		        return;
		     }
		    map.setMyLocationEnabled(true);
		}
		
		private void setUpMap(Location location) {
					
	        /*if (map != null) {
	                LatLng loc = new LatLng(location.getLatitude(), location.getLongitude());
	                map.addMarker(new MarkerOptions().position(loc).title("Marker"));
	                CameraUpdate center= CameraUpdateFactory.newLatLngZoom(loc, 100);
	                 if (center != null)  {
	                	 map.moveCamera(center);
	                 }
	        }*/
			LatLng loc = new LatLng(25.033611, 121.565000);
	        MarkerOptions markerOpt = new MarkerOptions();
	        markerOpt.position(new LatLng(25.033611, 121.565000));
	        markerOpt.title("�x�_101");
	        markerOpt.snippet("��1999�~�ʤu�A2004�~12��31�駹�u�ҥΡA�Ӱ�509.2���ءC");
	        markerOpt.draggable(false);
	        markerOpt.visible(true);
	        markerOpt.anchor(0.5f, 0.5f);//�]���Ϥ�����
	        markerOpt.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_launcher));

	        map.addMarker(markerOpt);
	        CameraUpdate center= CameraUpdateFactory.newLatLngZoom(loc, 10);
	        if (center != null)  {
	        	map.moveCamera(center);
	        }
		}
		
		private OnMapClickListener click = new OnMapClickListener() {
	        @Override
	        public void onMapClick(LatLng point) {
	      /* �I���a�ϲ��ʦܥH�Ὤ�������ߪ��a�ϵe�� */
	            CameraUpdate center = CameraUpdateFactory.newLatLng(Hualien);
	            map.animateCamera(center);
	        }
	    };
		
		@Override
		public void onLocationChanged(Location location) {
			// TODO Auto-generated method stub
	        String locationContent = "�n�סG" + location.getLatitude() + 
                    "\n�g�סG" + location.getLongitude() +
                    "\n��סG" + location.getAccuracy() +
                    "\n�а��G" + location.getAltitude() +
                    "\n�ɶ��G" + location.getTime() +
                    "\n�t�סG" + location.getSpeed() + 
                    "\n���G" + location.getBearing();
	        		Toast.makeText(getActivity(), locationContent, Toast.LENGTH_SHORT).show();
		}
		
		@Override
		public void onResume() {
		        super.onResume();
		        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 100, 0, this);   //���w��ɥ�
		        m.onResume(); 
		        this.setUpMapIfNeeded();
		}
		
		@Override
		public void onPause() {
		        super.onPause();
		        m.onPause();
		        lm.removeUpdates(this);
		}
		@Override
		public void onDestroy() {
		        super.onDestroy();
		        m.onDestroy();
		}
		@Override
		public void onLowMemory() {
		        super.onLowMemory();
		        m.onLowMemory();
		}
		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub
			
		}
		public void showMessage(final String msg)   {
	        getActivity().runOnUiThread(new Runnable() {
	                 public void run()  {
	                               Toast.makeText(getActivity(), msg, Toast.LENGTH_LONG).show();
	                 }
	         });
		}
	
		public static class CreateThread extends Thread {
	        private HttpClient httpClient;    
	        private PlaceholderFragment parent;
	        private String url;
	        public CreateThread(String urlstr, String name, PlaceholderFragment p) {  
	        	super(name);
	        	parent = p;
	        	url = urlstr;
	        	httpClient = new DefaultHttpClient();  
	        }  
	        @Override  
	        public void run() {  
	                HttpGet get = new HttpGet(url);	    	 
	                HttpResponse response;
	                try {
	                        response = httpClient.execute(get);
	                        HttpEntity resEntity = response.getEntity();
	                        String result = EntityUtils.toString(resEntity);
	                        parent.showMessage(result);
	                } catch (ClientProtocolException e) {
	                        e.printStackTrace();
	                } catch (IOException e) {
	                        e.printStackTrace();
	                }  
	        } 
		}
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			CreateThread thread1 = new CreateThread("http://1-dot-myblackjackforandroid.appspot.com/HelloServlet","user1", this);
			thread1.start();
		}
		
	}
	
}
