package com.example.test;

import android.provider.BaseColumns;

public class DB_Member_Sign implements BaseColumns {
	public static final String TABLE_NAME = "member";
	public static final String COLUMN_NAME_Account = "account";
	public static final String COLUMN_NAME_NAME = "name";
	public static final String COLUMN_NAME_Password = "password";
	public static final String COLUMN_NAME_Phone = "Phone";
	public static final String COLUMN_NAME_Email = "Email";

	public static final String CREATE_VITAL_TABLE = "CREATE TABLE "
			+ TABLE_NAME + " (" + _ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
			+ COLUMN_NAME_Account + " TEXT, " + COLUMN_NAME_NAME + " TEXT, "
			+ COLUMN_NAME_Password + " TEXT, " + COLUMN_NAME_Phone + " TEXT, " + COLUMN_NAME_Email + " TEXT)";

	public static final String DROP_VITAL_TABLE = "DROP TABLE IF EXISTS "
			+ TABLE_NAME;

}
