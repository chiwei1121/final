package com.example.test;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

public class Look extends ActionBarActivity {
	static DB_Member_OpenHelper db_Member_Helper;//*****
	static String state="",account="",password="";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_look);
		
		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}
		Bundle bundle = this.getIntent().getExtras();
		state = bundle.getString("state");
		Log.v("state",state);
		account = bundle.getString("account");
		password = bundle.getString("password");
		db_Member_Helper = new DB_Member_OpenHelper(this);//*****
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.look, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static  class PlaceholderFragment extends Fragment implements OnClickListener {
		ListView lv;
		Button contine;
		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_look, container,
					false);
			lv = (ListView)rootView.findViewById(R.id.listView1);
			contine= (Button)rootView.findViewById(R.id.button1);
			contine.setOnClickListener(this);
			SQLiteDatabase db = db_Member_Helper.getReadableDatabase();//*****
			Cursor c = null;
			if("register".equals(state))
			{
				c = db.query(DB_Member_Sign.TABLE_NAME, null, null, null, null,null, null);
				Log.v("1","1");
			}
			else if("login".equals(state))
			{
				Log.v("2","2");
				c = db.query(DB_Member_Sign.TABLE_NAME, null, "account='"+account+"' AND password='"+password+"'", null, null,null, null);
			}
			Log.v("1","3");
			
			c = db.query(DB_Member_Sign.TABLE_NAME, null, null, null, null,null, null);
			ArrayList<HashMap<String, String>> mList = new ArrayList<HashMap<String, String>>();
			SimpleAdapter Adapter;
			c.moveToFirst();
			while (!c.isAfterLast()) {
				HashMap<String, String> item = new HashMap<String, String>();
				item.put("account",c.getString(c.getColumnIndex(DB_Member_Sign.COLUMN_NAME_Account)));
				item.put("name", c.getString(c.getColumnIndex(DB_Member_Sign.COLUMN_NAME_NAME)));
				item.put("password", c.getString(c.getColumnIndex(DB_Member_Sign.COLUMN_NAME_Password)));
				item.put("phone", c.getString(c.getColumnIndex(DB_Member_Sign.COLUMN_NAME_Phone)));
				item.put("email", c.getString(c.getColumnIndex(DB_Member_Sign.COLUMN_NAME_Email)));
				mList.add(item);
				c.moveToNext();
			}
			Adapter = new SimpleAdapter(this.getActivity(), mList, R.layout.column,new String[] {"account","name","password","phone","email"}, new int[] {R.id.Text_account,R.id.Text_Name,R.id.Text_Pwd,R.id.Text_Phone,R.id.Text_Email});
			lv.setAdapter(Adapter);
			
			return rootView;
		}

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			if(v == contine)
			{
				Intent i = new Intent();
				i.setClass(this.getActivity(), Mapfragment.class);
			}
		}
		
		

	}

}
